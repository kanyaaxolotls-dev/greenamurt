<div class="page">
    <div class="navbar navbar-page">
        <div class="navbar-inner sliding">
            <div class="left">
                <a href="#" class="link back">
                    <i class="fas fa-arrow-left"></i>
                </a>
            </div>
            <div class="title">
                Offers Zone
            </div>
            <div class="right"></div>
        </div>
    </div>
    <div class="page-content">
        <!-- blog -->
        <div class="blog segments">
            <div class="container">
                <div class="row">
                    <div class="col-50">
                        <div class="content content-shadow-product">
                            <div class="blog-category">
                                <p>App</p>
                            </div>
                            <img src="images/blog1.jpg" alt="">
                            <div class="text">
                                <a href="/blog-single/"><h5>Automatically drag applications</h5></a>
                                <p class="date">August 21, 2019</p>
                                <div class="wrap-blog-action">
                                    <ul>
                                        <li><i class="fas fa-heart"></i>98</li>
                                        <li><i class="fas fa-comment"></i>51</li>
                                        <li><i class="fas fa-share-alt"></i></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-50">
                        <div class="content content-shadow-product">
                            <div class="blog-category">
                                <span>Design</span>
                            </div>
                            <img src="images/blog2.jpg" alt="">
                            <div class="text">
                                <a href="/blog-single/"><h5>Make a wall picture for the house</h5></a>
                                <p class="date">August 21, 2019</p>
                                <div class="wrap-blog-action">
                                    <ul>
                                        <li><i class="fas fa-heart"></i>98</li>
                                        <li><i class="fas fa-comment"></i>51</li>
                                        <li><i class="fas fa-share-alt"></i></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-50">
                        <div class="content content-shadow-product">
                            <div class="blog-category">
                                <p>Design</p>
                            </div>
                            <img src="images/blog3.jpg" alt="">
                            <div class="text">
                                <a href="/blog-single/"><h5>Wood motive table for background</h5></a>
                                <p class="date">August 21, 2019</p>
                                <div class="wrap-blog-action">
                                    <ul>
                                        <li><i class="fas fa-heart"></i>98</li>
                                        <li><i class="fas fa-comment"></i>51</li>
                                        <li><i class="fas fa-share-alt"></i></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-50">
                        <div class="content content-shadow-product">
                            <div class="blog-category">
                                <p>Graphic</p>
                            </div>
                            <img src="images/blog4.jpg" alt="">
                            <div class="text">
                                <a href="/blog-single/"><h5>Prototype of a hospital building</h5></a>
                                <p class="date">August 21, 2019</p>
                                <div class="wrap-blog-action">
                                    <ul>
                                        <li><i class="fas fa-heart"></i>98</li>
                                        <li><i class="fas fa-comment"></i>51</li>
                                        <li><i class="fas fa-share-alt"></i></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-50">
                        <div class="content content-shadow-product">
                            <div class="blog-category">
                                <p>Illustration</p>
                            </div>
                            <img src="images/blog5.jpg" alt="">
                            <div class="text">
                                <a href="/blog-single/"><h5>Division of territory in the world</h5></a>
                                <p class="date">August 21, 2019</p>
                                <div class="wrap-blog-action">
                                    <ul>
                                        <li><i class="fas fa-heart"></i>98</li>
                                        <li><i class="fas fa-comment"></i>51</li>
                                        <li><i class="fas fa-share-alt"></i></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-50">
                        <div class="content content-shadow-product">
                            <div class="blog-category">
                                <p>Graphic</p>
                            </div>
                            <img src="images/blog6.jpg" alt="">
                            <div class="text">
                                <a href="/blog-single/"><h5>Typography for decorating</h5></a>
                                <p class="date">August 21, 2019</p>
                                <div class="wrap-blog-action">
                                    <ul>
                                        <li><i class="fas fa-heart"></i>98</li>
                                        <li><i class="fas fa-comment"></i>51</li>
                                        <li><i class="fas fa-share-alt"></i></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- divider -->
                <div class="divider-space-content"></div>
                <!-- end divider -->

                <div class="pagination">
                    <ul>
                        <li class="arrow-prev"><a href="#"><i class="fas fa-chevron-left"></i></a></li>
                        <li class="pagination-active"><a href="#">1</a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#">4</a></li>
                        <li><a href="#">5</a></li>
                        <li class="arrow-next"><a href="#"><i class="fas fa-chevron-right"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- end blog -->
    </div>
</div>