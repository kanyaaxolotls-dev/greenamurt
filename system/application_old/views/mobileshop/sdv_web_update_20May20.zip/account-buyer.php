<div class="page">
    <div class="navbar navbar-page">
        <div class="navbar-inner sliding">
            <div class="left">
                <a href="#" class="link back">
                    <i class="fas fa-arrow-left"></i>
                </a>
            </div>
            <div class="title">
                My Account
            </div>
            <div class="right"></div>
        </div>
    </div>
    <div class="page-content">
        <!-- account buyer -->
        <div class="account-buyer segments">
            <div class="container">
                <div class="header-account content-shadow">
                    <img src="images/user-buyer6.png" alt="">
                    <div class="title-name">
                        <h5>Maharashtra</h5>
                        <p><i class="fas fa-map-marker-alt"></i>India</p>
                    </div>
                </div>
            </div>
            <div class="container segments">
                <div class="info-balance content-shadow">
                    <div class="row">
                        <div class="col-50">
                            <div class="content-text">
                                <p>Your Balance</p>
                                <h5>$310.00</h5>
                            </div>
                        </div>
                        <div class="col-50">
                            <div class="content-button">
                                <a href="#" class="button primary-button"><i class="fas fa-wallet"></i>Top Up</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="account-menu">
                <div class="list media-list">
                    <ul>
                        <li>
                            <a href="/wishlist/" class="item-link item-content">
                                <div class="item-media">
                                    <i class="fas fa-heart"></i>
                                </div>
                                <div class="item-inner">
                                    <div class="item-title-row">
                                        <div class="item-title">Wishlist</div>
                                    </div>
                                    <div class="item-subtitle">All products that you have saved</div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="/transaction/" class="item-link item-content">
                                <div class="item-media">
                                    <i class="fas fa-exchange-alt"></i>
                                </div>
                                <div class="item-inner">
                                    <div class="item-title-row">
                                        <div class="item-title">Transaction</div>
                                    </div>
                                    <div class="item-subtitle">All your transactions are here</div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="/notification/" class="item-link item-content">
                                <div class="item-media">
                                    <i class="fas fa-bell"></i>
                                </div>
                                <div class="item-inner">
                                    <div class="item-title-row">
                                        <div class="item-title">Notification</div>
                                    </div>
                                    <div class="item-subtitle">Transaction, Purchase, Notification update</div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="/faq/" class="item-link item-content">
                                <div class="item-media">
                                    <i class="fas fa-question"></i>
                                </div>
                                <div class="item-inner">
                                    <div class="item-title-row">
                                        <div class="item-title">Help</div>
                                    </div>
                                    <div class="item-subtitle">Need Help, Frequently Asked Questions</div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="/contact-seller/" class="item-link item-content">
                                <div class="item-media">
                                    <i class="fas fa-envelope"></i>
                                </div>
                                <div class="item-inner">
                                    <div class="item-title-row">
                                        <div class="item-title">Contact Seller</div>
                                    </div>
                                    <div class="item-subtitle">Other questions can contact me</div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="item-link item-content">
                                <div class="item-media">
                                    <i class="fas fa-power-off"></i>
                                </div>
                                <div class="item-inner">
                                    <div class="item-title">Logout</div>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- end  account buyer -->
    </div>
</div>