<div class="page">
    <div class="navbar navbar-page">
        <div class="navbar-inner sliding">
            <div class="left">
                <a href="#" class="link back">
                    <i class="fas fa-arrow-left"></i>
                </a>
            </div>
            <div class="title">
                Apparel
            </div>
        </div>
    </div>
    <div class="page-content">
        <!-- categoreis details -->
        <div class="categories-details segments">
            <div class="container">
                <!-- slider categories -->
                <div class="slider-categories">
                    <div data-pagination='{"el": ".swiper-pagination"}' data-space-between="10" class="swiper-container swiper-init swiper-container-horizontal">
                        <div class="swiper-pagination"></div>
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="content">
                                    <div class="mask"></div>
                                    <img src="images/banner5.png" alt="">
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="content">
                                    <div class="mask"></div>
                                    <img src="images/banner4.png" alt="">
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="content">
                                    <div class="mask"></div>
                                    <img src="images/banner6.png" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end slider categories -->
            </div>

            <!-- sub-categories -->
            <div class="sub-categories segments">
                <div class="container">
                    <div class="row">
                        <div class="col-20">
                            <div class="content">
                                <a href="/categories-details/">
                                    <div class="icon">
                                        <i class="fas fa-tshirt"></i>
                                    </div>
                                    <span>T-shirta</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-20">
                            <div class="content">
                                <a href="/categories-details/">
                                    <div class="icon">
                                        <i class="fas fa-car"></i>
                                    </div>
                                    <span>Jacket</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-20">
                            <div class="content">
                                <a href="/categories-details/">
                                    <div class="icon">
                                        <i class="fas fa-chair radi"></i>
                                    </div>
                                    <span>Gloves</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-20">
                            <div class="content">
                                <a href="/categories-details/">
                                    <div class="icon">
                                        <i class="fas fa-camera"></i>
                                    </div>
                                    <span>Socks</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-20">
                            <div class="content">
                                <a href="/categories-details/">
                                    <div class="icon">
                                        <i class="fas fa-headphones-alt"></i>
                                    </div>
                                    <span>Pants</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end sub-categories -->

            <!-- recommended for you -->
            <div class="recommended-you">
                <div class="container">
                    <div class="section-title">
                        <h3>Recommended</h3>
                    </div>
                    <div data-space-between="10" data-slides-per-view="auto" class="swiper-container swiper-init">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="content content-shadow-product">
                                    <a href="#">
                                        <img src="images/product1.jpg" alt="">
                                        <div class="text">
                                            <p class="title-product">Sweater with triangle collar</p>
                                            <p class="price">$70.00</p>
                                            <p class="location">New York</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="content content-shadow-product">
                                    <a href="#">
                                        <img src="images/product3.jpg" alt="">
                                        <div class="text">
                                            <p class="title-product">Jacket for adventure</p>
                                            <p class="price">$99.99</p>
                                            <p class="location">New York</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="content content-shadow-product">
                                    <a href="#">
                                        <img src="images/product5.jpg" alt="">
                                        <div class="text">
                                            <p class="title-product">Shirt with long sleeve black</p>
                                            <p class="price">$66.00</p>
                                            <p class="location">New York</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="content content-shadow-product">
                                    <a href="#">
                                        <img src="images/product6.jpg" alt="">
                                        <div class="text">
                                            <p class="title-product">Long-sleeved gray sweater</p>
                                            <p class="price">$75.00</p>
                                            <p class="location">New York</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end recommended for you -->

            <!-- popular new product -->
            <div class="popular-new-product">
                <div class="container">
                    <div class="section-title">
                        <h3>Popular New Product</h3>
                    </div>
                    <div data-space-between="10" data-slides-per-view="auto" class="swiper-container swiper-init">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="content content-shadow-product">
                                    <a href="#">
                                        <div class="product-mark-new">
                                            <span>NEW</span>
                                        </div>
                                        <img src="images/product9.jpg" alt="">
                                        <div class="text">
                                            <p class="title-product">Long-sleeved gray sweater</p>
                                            <p class="price">$87.00</p>
                                            <p class="location">New York</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="content content-shadow-product">
                                    <a href="#">
                                        <div class="product-mark-new">
                                            <span>NEW</span>
                                        </div>
                                        <img src="images/product10.jpg" alt="">
                                        <div class="text">
                                            <p class="title-product">Thick jacket suitable</p>
                                            <p class="price">$145.00</p>
                                            <p class="location">New York</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="content content-shadow-product">
                                    <a href="#">
                                        <div class="product-mark-new">
                                            <span>NEW</span>
                                        </div>
                                        <img src="images/product11.jpg" alt="">
                                        <div class="text">
                                            <p class="title-product">Shirt long sleeve - black</p>
                                            <p class="price">$88.00</p>
                                            <p class="location">New York</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="content content-shadow-product">
                                    <a href="#">
                                        <div class="product-mark-new">
                                            <span>NEW</span>
                                        </div>
                                        <img src="images/flash-sale1.jpg" alt="">
                                        <div class="text">
                                            <p class="title-product">Premium shirt plain smooth</p>
                                            <p class="price">$60.00</p>
                                            <p class="location">New York</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end popular new product -->
        </div>
        <!-- end categoreis details -->
    </div>
</div>