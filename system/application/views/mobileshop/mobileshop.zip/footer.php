	<script src="<?php echo base_url('axxets/mobileshop/js/framework7.bundle.min.js')?>"></script>
	<script src="<?php echo base_url('axxets/mobileshop/js/routes.js')?>"></script>
	<script src="<?php echo base_url('axxets/mobileshop/js/app.js')?>"></script>


</body>
</html>