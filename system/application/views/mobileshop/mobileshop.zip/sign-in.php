<?php $this->load->view('mobileshop/header'); ?>
<div class="page">
    <div class="navbar navbar-page">
        <div class="navbar-inner sliding">
            <div class="left">
                <a href="#" class="link back">
                    <i class="fas fa-arrow-left"></i>
                </a>
            </div>
            <div class="title">
                Sign In
            </div>
            <div class="right"></div>
        </div>
    </div>
    <div class="page-content">
        <!-- sign in -->
       
        <div class="sign-in segments">
             

             <?php echo form_open() ?> 

            <div class="container">
                <?php echo validation_errors('<div class="alert alert-danger">', '</div>') ?>
                  <?php echo $this->session->flashdata('site_flash') ?>
                  <?php if (config_item('is_demo') != TRUE) {
                       echo '<div class="alert alert-danger">Please Pay your remaining balance to remove this banner !<br/> इस बैनर को हटाने के लिए कृपयाअपनी शेष राशि का भुगतान करें !</div>';
                  } ?>
                <div class="list">
                    <ul>
                        <li class="item-content item-input">
                            <div class="item-inner">
                                <div class="item-input-wrap">
                                    <input type="text" placeholder="username" name="username" id="user" >
                                </div>
                            </div>
                        </li>
                        <li class="item-content item-input">
                            <div class="item-inner">
                                <div class="item-input-wrap">
                                    <input type="password" placeholder="Password" name="password">
                                </div>
                            </div>
                        </li> 
                    </ul>
                    <div class="wrap-link-action">
                        <ul> 
                            <li>
                                <label class="item-checkbox item-content">
                                    <input type="checkbox">
                                    <i class="icon icon-checkbox"></i>
                                    <div class="item-inner">
                                        <div class="item-title">Remember me</div>
                                    </div>
                                </label>
                            </li>
                            <li><a href="<?php echo site_url('site/forgotpw') ?>">Forgot Password</a></li>
                        </ul>
                    </div>
                    <div class="content-button">
                      
                         <button class="button primary-button">Login</button>
                    </div>
                </div>
                 <?php echo form_close() ?>
                <!-- divider -->
                <div class="divider-space-content"></div>
                <!-- end divider -->

                <div class="wrap-sign-in-with">
                    <div class="title">
                        <p>or sign in with</p>
                        <span></span>
                    </div>
                    <div class="wrap-media-sign-in">
                        <div class="row">
                            <div class="col-33">
                                <a href="#">
                                    <div class="content bg-facebook">
                                        <i class="fab fa-facebook-f"></i>
                                    </div>
                                </a>
                            </div>
                            <div class="col-33">
                                <a href="#">
                                    <div class="content bg-twitter">
                                        <i class="fab fa-twitter"></i>
                                    </div>
                                </a>
                            </div>
                            <div class="col-33">
                                <a href="#">
                                    <div class="content bg-google">
                                        <i class="fab fa-google"></i>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- divider -->
                <div class="divider-space-content"></div>
                <!-- end divider -->

                <div class="wrap-link-sign-in">
                    <p>Don't have an account? <a href="/sign-up/">Sign Up</a></p>
                </div>
            </div>

        </div>
        <!-- end sign in -->
    </div>
</div>
<?php  $this->load->view('mobileshop/footer'); ?>