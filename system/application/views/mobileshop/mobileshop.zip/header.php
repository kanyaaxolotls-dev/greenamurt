<!DOCTYPE html>
<html lang="en">
<head> 
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="default">
	<meta http-equiv="Content-Security-Policy" content="default-src * 'self' 'unsafe-inline' 'unsafe-eval' data: gap:">

	<link rel="icon" href="<?php echo base_url('axxets/mobileshop/favicon.png')?>">
	<title>SDV APP</title> 
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,500i,700,900&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo base_url('axxets/mobileshop/css/framework7.bundle.css')?>"> 
	<link rel="stylesheet" href="<?php echo base_url('axxets/mobileshop/css/font-awesome.css')?>">
	<link rel="stylesheet" href="<?php echo base_url('axxets/mobileshop/css/style.css')?>">


</head>
<body>