<div class="page">
    <div class="navbar navbar-page">
        <div class="navbar-inner sliding">
            <div class="left">
                <a href="#" class="link back">
                    <i class="fas fa-arrow-left"></i>
                </a>
            </div>
            <div class="title">
                Contact Seller
            </div>
            <div class="right"></div>
        </div>
    </div>
    <div class="page-content">
        <!-- contact seller -->
        <div class="password-settings segments">
            <div class="container">
                <form class="list">
                    <ul>
                        <li class="item-content item-input">
                            <div class="item-inner">
                                <div class="item-input-wrap">
                                    <input type="text" placeholder="Name">
                                </div>
                            </div>
                        </li>
                        <li class="item-content item-input">
                            <div class="item-inner">
                                <div class="item-input-wrap">
                                    <input type="email" placeholder="Email">
                                </div>
                            </div>
                        </li>
                        <li class="item-content item-input">
                            <div class="item-inner">
                                <div class="item-input-wrap">
                                    <input type="text" placeholder="Subject">
                                </div>
                            </div>
                        </li>
                        <li class="item-content item-input">
                            <div class="item-inner">
                                <div class="item-input-wrap">
                                    <textarea cols="30" rows="10" placeholder="Message"></textarea>
                                </div>
                            </div>
                        </li>
                    </ul>
                    <div class="content-button">
                        <a href="#" class="button primary-button"><i class="fas fa-paper-plane"></i>Send</a>
                    </div>
                </form>
            </div>
        </div>
        <!-- end contact seller -->
    </div>
</div>